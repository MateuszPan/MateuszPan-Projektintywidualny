using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace QuizGameHistory5
{
    public partial class Form1 : Form
    {
        private System.Windows.Forms.Timer gameTimer;
        private Panel welcomePanel = new Panel();
        private Panel preWelcomePanel = new Panel();
        private Panel epochPanel = new Panel();
        private Panel difficultyPanel = new Panel();
        private Panel questionPanel = new Panel();
        private Button[] answerButtons = Array.Empty<Button>();
        private List<string[]> questionsAndAnswersList = new List<string[]>();
        private HashSet<int> usedQuestionIndices = new HashSet<int>();
        private int currentQuestionIndex = 0;
        private int correctAnswersCount = 0;
        private int incorrectAnswersCount = 0;
        private int skippedQuestionsCount = 0;
        private int totalQuestionsCount = 0;
        private string currentEpochName;
        private string currentDifficulty;
        private Random random = new Random();
        private DateTime gameStartTime;
        private Label timerLabel = new Label();
        private TextBox playerNameTextBox;

        private Dictionary<string, int> playerScores = new Dictionary<string, int>();

        private string scoresFilePath = @"C:\Users\User\QuizGameHistory5\QuizGameHistory5\bin\Debug\net8.0-windows\scores.txt";

        public Form1()
        {
            InitializeComponent();
            this.Size = new Size(1000, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializePreWelcomePanel();

            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = 1000;
            gameTimer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timerLabel.Text = $"Czas: {GetElapsedTime()}";
        }

        private void StartGameTimer()
        {
            gameStartTime = DateTime.Now;
            gameTimer.Start();
        }

        private string GetElapsedTime()
        {
            if (gameStartTime == default(DateTime))
            {
                return "0:00:00";
            }
            else
            {
                TimeSpan elapsedTime = DateTime.Now - gameStartTime;
                return $"{(int)elapsedTime.TotalMinutes:D2}:{elapsedTime.Seconds:D2}";
            }
        }

        private void InitializePreWelcomePanel()
        {
            preWelcomePanel.Size = new Size(400, 500);
            preWelcomePanel.BackColor = Color.Transparent;
            preWelcomePanel.BackgroundImage = Image.FromFile(@"Resources\tlo_epoka1.jpg");
            preWelcomePanel.BackgroundImageLayout = ImageLayout.Stretch;
            preWelcomePanel.Location = new Point((this.Width - preWelcomePanel.Width) / 2, (this.Height - preWelcomePanel.Height) / 2);

            Label preWelcomeTitleLabel = new Label();
            preWelcomeTitleLabel.Text = "Sprawdź swoją wiedzę historyczną";
            preWelcomeTitleLabel.Font = new Font(preWelcomeTitleLabel.Font.FontFamily, 12, FontStyle.Bold);
            preWelcomeTitleLabel.TextAlign = ContentAlignment.MiddleCenter;
            preWelcomeTitleLabel.AutoSize = false;
            preWelcomeTitleLabel.Size = new Size(preWelcomePanel.Width - 80, 60);
            preWelcomeTitleLabel.Location = new Point((preWelcomePanel.Width - preWelcomeTitleLabel.Width) / 2, (this.Height - preWelcomePanel.Height) / 2 - 20);
            preWelcomePanel.Controls.Add(preWelcomeTitleLabel);

            playerNameTextBox = new TextBox();
            playerNameTextBox.Size = new Size(200, 30);
            playerNameTextBox.Location = new Point((preWelcomePanel.Width - playerNameTextBox.Width) / 2, preWelcomeTitleLabel.Bottom + 20);
            preWelcomePanel.Controls.Add(playerNameTextBox);

            Button playButton = new Button();
            playButton.Size = new Size(200, 50);
            playButton.Text = "Chcesz zagrać? Naciśnij mnie.";
            playButton.Location = new Point((preWelcomePanel.Width - playButton.Width) / 2, playerNameTextBox.Bottom + 20);
            playButton.Click += (sender, e) => ShowEpochPanel();
            preWelcomePanel.Controls.Add(playButton);

            this.Controls.Add(preWelcomePanel);
        }

        private void ShowEpochPanel()
        {
            preWelcomePanel.Visible = false;
            InitializeEpochPanel();
        }

        private void InitializeEpochPanel()
        {
            epochPanel.Size = new Size(400, 500);
            epochPanel.BackColor = Color.Transparent;
            epochPanel.BackgroundImage = Image.FromFile(@"Resources\tlo_epoka1.jpg");
            epochPanel.BackgroundImageLayout = ImageLayout.Stretch;
            epochPanel.Location = new Point((this.Width - epochPanel.Width) / 2, (this.Height - epochPanel.Height) / 2);

            Label titleLabel = new Label();
            titleLabel.Text = "Wybierz epokę:";
            titleLabel.Font = new Font(titleLabel.Font.FontFamily, 11, FontStyle.Bold);
            titleLabel.AutoSize = true;
            titleLabel.Location = new Point((epochPanel.Width - titleLabel.Width) / 2, 110);
            epochPanel.Controls.Add(titleLabel);

            AddEpochButton("Starożytność", "starozytnosc", 140);
            AddEpochButton("Średniowiecze", "sredniowiecze", 190);
            AddEpochButton("Nowożytność", "nowozytnosc", 240);
            AddEpochButton("Współczesność", "wspolczesnosc", 290);

            this.Controls.Add(epochPanel);
        }

        private void AddEpochButton(string text, string epochName, int yOffset)
        {
            Button epochButton = new Button();
            epochButton.Size = new Size(200, 50);
            epochButton.Text = text;
            epochButton.Location = new Point((epochPanel.Width - epochButton.Width) / 2, yOffset);
            epochButton.Click += (sender, e) => EpochButton_Click(sender, e, epochName);
            epochPanel.Controls.Add(epochButton);
        }

        private void EpochButton_Click(object sender, EventArgs e, string epochName)
        {
            currentEpochName = epochName;
            string selectedFile = Path.Combine(Application.StartupPath, "Resources", $"{epochName}normalny.csv");
            LoadQuestionsFromFile(selectedFile);
            InitializeDifficultyPanel(epochName);
            epochPanel.Visible = false;
        }

        private void InitializeDifficultyPanel(string epochName)
        {
            difficultyPanel.Size = new Size(400, 500);
            difficultyPanel.BackColor = Color.Transparent;
            difficultyPanel.BackgroundImage = Image.FromFile(@"Resources\tlo_epoka1.jpg");
            difficultyPanel.BackgroundImageLayout = ImageLayout.Stretch;
            difficultyPanel.Location = new Point((this.Width - difficultyPanel.Width) / 2, (this.Height - difficultyPanel.Height) / 2);

            Label titleLabel = new Label();
            titleLabel.Text = "Wybierz poziom trudności:";
            titleLabel.Font = new Font(titleLabel.Font.FontFamily, 11, FontStyle.Bold);
            titleLabel.TextAlign = ContentAlignment.MiddleCenter;
            titleLabel.AutoSize = false;
            titleLabel.Size = new Size(difficultyPanel.Width - 80, 60);
            titleLabel.Location = new Point((difficultyPanel.Width - titleLabel.Width) / 2, 50 + 32);
            difficultyPanel.Controls.Add(titleLabel);

            AddDifficultyButton("Poziom normalny", "normalny", epochName);
            AddDifficultyButton("Poziom trudny", "trudny", epochName);
            AddDifficultyButton("Poziom ekspert", "ekspert", epochName);

            this.Controls.Add(difficultyPanel);
        }

        private void AddDifficultyButton(string text, string difficulty, string epochName)
        {
            Button difficultyButton = new Button();
            difficultyButton.Size = new Size(200, 50);
            difficultyButton.Text = text;
            difficultyButton.Location = new Point((difficultyPanel.Width - difficultyButton.Width) / 2, 140 + 60 * difficultyPanel.Controls.OfType<Button>().Count());
            difficultyButton.Click += (sender, e) => DifficultyButton_Click(sender, e, difficulty, epochName);
            difficultyPanel.Controls.Add(difficultyButton);
        }

        private void DifficultyButton_Click(object sender, EventArgs e, string difficulty, string epochName)
        {
            currentDifficulty = difficulty;
            string selectedFile = Path.Combine(Application.StartupPath, "Resources", $"{epochName}{difficulty}.csv");
            LoadQuestionsFromFile(selectedFile);
            InitializeQuestionPanel();
            difficultyPanel.Visible = false;
            StartGameTimer();
        }

        private void InitializeQuestionPanel()
        {
            questionPanel.Controls.Clear();

            questionPanel.Size = new Size(800, 600);
            questionPanel.BackColor = Color.Transparent;

            string backgroundImagePath = Path.Combine(Application.StartupPath, "Resources", $"{currentEpochName}_tlo.jpg");
            if (File.Exists(backgroundImagePath))
            {
                questionPanel.BackgroundImage = Image.FromFile(backgroundImagePath);
                questionPanel.BackgroundImageLayout = ImageLayout.Stretch;
            }
            else
            {
                questionPanel.BackColor = Color.LightBlue;
            }

            questionPanel.BorderStyle = BorderStyle.FixedSingle;
            questionPanel.Location = new Point((this.Width - questionPanel.Width) / 2, (this.Height - questionPanel.Height) / 2);

            Button exitButton = new Button();
            exitButton.Size = new Size(150, 50);
            exitButton.Text = "Wyjście z gry";
            exitButton.Location = new Point((questionPanel.Width - exitButton.Width) / 2, questionPanel.Height - exitButton.Height - 20);
            exitButton.Click += (sender, e) => Application.Exit();
            questionPanel.Controls.Add(exitButton);

            if (usedQuestionIndices.Count == questionsAndAnswersList.Count)
            {
                ShowSummaryPanel();
                return;
            }

            currentQuestionIndex = GetRandomUnaskedQuestionIndex();

            Panel questionRectangle = new Panel();
            questionRectangle.Size = new Size(500, 50);
            questionRectangle.BackColor = Color.LightGreen;
            questionRectangle.BorderStyle = BorderStyle.FixedSingle;
            questionRectangle.Location = new Point((questionPanel.Width - questionRectangle.Width) / 2, 50);
            questionPanel.Controls.Add(questionRectangle);

            Label questionLabel = new Label();
            questionLabel.Text = questionsAndAnswersList[currentQuestionIndex][0];
            questionLabel.AutoSize = false;
            questionLabel.TextAlign = ContentAlignment.MiddleCenter;
            questionLabel.Font = new Font(questionLabel.Font, FontStyle.Bold);
            questionLabel.Dock = DockStyle.Fill;
            questionRectangle.Controls.Add(questionLabel);

            List<string> answers = questionsAndAnswersList[currentQuestionIndex].Skip(1).ToList();
            answers.Shuffle();

            answerButtons = new Button[answers.Count];
            for (int i = 0; i < answerButtons.Length; i++)
            {
                answerButtons[i] = new Button();
                answerButtons[i].Size = new Size(400, 30);
                answerButtons[i].Text = answers[i];
                answerButtons[i].Location = new Point((questionPanel.Width - answerButtons[i].Width) / 2, questionRectangle.Location.Y + questionRectangle.Height + 30 + i * 40);
                answerButtons[i].Click += (sender, e) => AnswerButton_Click(sender, e, i);
                questionPanel.Controls.Add(answerButtons[i]);
            }

            string imageName = $"{currentQuestionIndex + 1}{currentEpochName}{currentDifficulty}.png";
            string imagePath = Path.Combine(Application.StartupPath, "Resources", imageName);

            if (!File.Exists(imagePath))
            {
                imageName = $"{currentQuestionIndex + 1}{currentEpochName}{currentDifficulty}.jpg";
                imagePath = Path.Combine(Application.StartupPath, "Resources", imageName);
            }

            if (File.Exists(imagePath))
            {
                Image originalImage = Image.FromFile(imagePath);

                int imageWidth, imageHeight;
                if (originalImage.Width > originalImage.Height)
                {
                    imageWidth = questionPanel.Width - 40;
                    imageHeight = (int)((double)originalImage.Height / originalImage.Width * imageWidth);
                }
                else
                {
                    imageHeight = questionPanel.Height - 40;
                    imageWidth = (int)((double)originalImage.Width / originalImage.Height * imageHeight);
                }

                if (imageWidth > 230 || imageHeight > 230)
                {
                    double scaleFactor = Math.Min(230.0 / imageWidth, 230.0 / imageHeight);
                    imageWidth = (int)(imageWidth * scaleFactor);
                    imageHeight = (int)(imageHeight * scaleFactor);
                }

                Image scaledImage = originalImage.GetThumbnailImage(imageWidth, imageHeight, null, IntPtr.Zero);

                PictureBox imageBox = new PictureBox();
                imageBox.Size = new Size(imageWidth, imageHeight);
                imageBox.SizeMode = PictureBoxSizeMode.StretchImage;
                imageBox.Image = scaledImage;
                imageBox.Location = new Point(questionPanel.Width - imageBox.Width - 40, questionPanel.Height - imageBox.Height - 40);
                questionPanel.Controls.Add(imageBox);
            }

            Button hideQuestionButton = new Button();
            hideQuestionButton.Size = new Size(100, 30);
            hideQuestionButton.Text = "Dalej";
            hideQuestionButton.Location = new Point((questionPanel.Width - hideQuestionButton.Width) / 2, answerButtons.Last().Bottom + 30);
            hideQuestionButton.Click += (sender, e) =>
            {
                skippedQuestionsCount++;
                questionPanel.Controls.Clear();
                InitializeQuestionPanel();
            };
            questionPanel.Controls.Add(hideQuestionButton);

            timerLabel = new Label();
            timerLabel.Text = $"Czas: {GetElapsedTime()}";
            timerLabel.AutoSize = true;
            timerLabel.Location = new Point(questionPanel.Width - timerLabel.Width - 20, 20);
            questionPanel.Controls.Add(timerLabel);

            this.Controls.Add(questionPanel);
        }

        private void LoadQuestionsFromFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                MessageBox.Show($"Plik {filePath} nie istnieje.", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (StreamReader sr = new StreamReader(filePath, System.Text.Encoding.UTF8))
                {
                    List<string> lines = new List<string>();
                    string currentLine;
                    while ((currentLine = sr.ReadLine()) != null)
                    {
                        lines.Add(currentLine);
                    }

                    questionsAndAnswersList = new List<string[]>();

                    foreach (var line in lines)
                    {
                        string[] parts = line.Split(',');
                        parts = parts.Select(part => part.Trim(';')).ToArray();
                        questionsAndAnswersList.Add(parts);
                    }

                    currentQuestionIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Wystąpił błąd podczas wczytywania pytań z pliku: {ex.Message}", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            totalQuestionsCount = questionsAndAnswersList.Count;
            usedQuestionIndices.Clear();
        }

        private int GetRandomUnaskedQuestionIndex()
        {
            if (usedQuestionIndices.Count == questionsAndAnswersList.Count)
            {
                return -1;
            }

            int randomIndex;
            do
            {
                randomIndex = random.Next(0, questionsAndAnswersList.Count);
            } while (usedQuestionIndices.Contains(randomIndex));

            usedQuestionIndices.Add(randomIndex);
            return randomIndex;
        }

        private void AnswerButton_Click(object sender, EventArgs e, int index)
        {
            Button clickedButton = (Button)sender;
            string selectedAnswer = clickedButton.Text;
            string correctAnswer = questionsAndAnswersList[currentQuestionIndex][1];

            if (selectedAnswer == correctAnswer)
            {
                MessageBox.Show("Dobrze!");
                correctAnswersCount++;
            }
            else
            {
                MessageBox.Show($"Zła odpowiedź. Prawidłowa odpowiedź to: {correctAnswer}");
                incorrectAnswersCount++;
            }

            questionPanel.Controls.Clear();
            InitializeQuestionPanel();
        }

        private void ShowSummaryPanel()
        {
            questionPanel.Controls.Clear();

            Panel counterPanel = new Panel();
            counterPanel.Size = new Size(450, 300);
            counterPanel.BackColor = Color.LightBlue;
            counterPanel.BorderStyle = BorderStyle.FixedSingle;
            counterPanel.Location = new Point((questionPanel.Width - counterPanel.Width) / 2, 50);
            questionPanel.Controls.Add(counterPanel);

            Label infoTitleLabel = new Label();
            infoTitleLabel.Text = "Ranking Top 5 Graczy:";
            infoTitleLabel.Font = new Font(infoTitleLabel.Font.FontFamily, 14, FontStyle.Bold);
            infoTitleLabel.AutoSize = true;
            infoTitleLabel.Location = new Point((counterPanel.Width - infoTitleLabel.Width) / 2, 20);
            counterPanel.Controls.Add(infoTitleLabel);

            Label currentPlayerLabel = new Label();
            currentPlayerLabel.Text = $"{playerNameTextBox.Text}: Dobrze: {correctAnswersCount}, Czas: {GetElapsedTime()}";
            currentPlayerLabel.Font = new Font(currentPlayerLabel.Font.FontFamily, 12, FontStyle.Regular);
            currentPlayerLabel.AutoSize = true;
            currentPlayerLabel.Location = new Point(20, 50);
            counterPanel.Controls.Add(currentPlayerLabel);

            List<PlayerScore> topScores = GetTopScores(5);
            int yOffset = 80;
            foreach (var score in topScores)
            {
                Label scoreLabel = new Label();
                scoreLabel.Text = $"{score.PlayerName}: Dobrze: {score.CorrectAnswers}, Czas: {score.ElapsedTime}";
                scoreLabel.Font = new Font(scoreLabel.Font.FontFamily, 12, FontStyle.Regular);
                scoreLabel.AutoSize = true;
                scoreLabel.Location = new Point(20, yOffset);
                counterPanel.Controls.Add(scoreLabel);
                yOffset += 30;
            }

            Button exitButton = new Button();
            exitButton.Size = new Size(150, 50);
            exitButton.Text = "Wyjście z gry";
            exitButton.Location = new Point((questionPanel.Width - exitButton.Width) / 2, questionPanel.Height - exitButton.Height - 20);
            exitButton.Click += (sender, e) => Application.Exit();
            questionPanel.Controls.Add(exitButton);

            SaveScoresToFile();

            SaveScore(playerNameTextBox.Text, correctAnswersCount);
        }

        private void SaveScoresToFile()

        {
            string filePath = Path.Combine(Application.StartupPath, "Scores", $"{currentEpochName}_{currentDifficulty}.txt");

            try
            {
                 using (StreamWriter sw = new StreamWriter(filePath, true))
                {
                    sw.WriteLine($"{playerNameTextBox.Text},{correctAnswersCount},{GetElapsedTime()}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Wystąpił błąd podczas zapisywania wyników: {ex.Message}", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private List<PlayerScore> GetTopScores(int count)
        {
            List<PlayerScore> topScores = new List<PlayerScore>();

            string filePath = Path.Combine(Application.StartupPath, "Scores", $"{currentEpochName}_{currentDifficulty}.txt");

            try
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length == 3)
                        {
                            string playerName = parts[0];
                            int correctAnswers = int.Parse(parts[1]);
                            string elapsedTime = parts[2];

                            topScores.Add(new PlayerScore(playerName, correctAnswers, elapsedTime));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Wystąpił błąd podczas wczytywania wyników: {ex.Message}", "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            topScores = topScores.OrderByDescending(score => score.CorrectAnswers).ThenBy(score => TimeSpan.Parse(score.ElapsedTime)).Take(count).ToList();


            return topScores;
        }

        private void SaveScore(string playerName, int score)
        {
            if (!playerScores.ContainsKey(playerName))
            {
                playerScores.Add(playerName, score);
            }
            else
            {
                playerScores[playerName] = Math.Max(playerScores[playerName], score);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveScore(playerNameTextBox.Text, correctAnswersCount);
        }
    }

    public class PlayerScore
    {
        public string PlayerName { get; }
        public int CorrectAnswers { get; }
        public string ElapsedTime { get; }

        public PlayerScore(string playerName, int correctAnswers, string elapsedTime)
        {
            PlayerName = playerName;
            CorrectAnswers = correctAnswers;
            ElapsedTime = elapsedTime;
        }
    }

    public static class Extensions
    {
        public static void Shuffle<T>(this IList<T> list)
        {
            Random rng = new Random();
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }
    }
}